# fortran-neural-network
A neural network written in Fortran, the best programming language in the universe!

Nothing fancy, just written for the purpose of playing around.

Input is fixed in the file, no file I/O yet.

Since the last update it can learn via backpropagation, but I haven't tested it much yet.
